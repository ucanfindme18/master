<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Server List</h1>
        </div>
    </div>
    <div class="row">
       <div class="col-xs-6 col-md-5 col-md-4 col-lg-3">
            <div class="well">Balance : <B><?php echo $me->saldo; ?></B></div>
        </div>
    </div>
    <div class="row">
        <?php if ($message): ?>
            <div class="col-lg-12">
                <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
            </div>
        <?php endif; ?>
        <?php foreach (($servers?:array()) as $server): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <b><?php echo $server->servername; ?></b> <?php echo $server->active==1?'':'( Locked )'; ?>
                    </div>
                    <table class="table">
                        <tr>
                            <td>Location</td><td><?php echo $server->country; ?></td>
                        </tr>
                        <tr>
                            <td>Host</td><td><?php echo $server->host; ?></td>
                        </tr>
                        <tr>
                            <td>Price</td><td><?php echo $server->price; ?></td>
                        </tr>
                    </table>
                    <div class="panel-footer text-center">
                        <a href="<?php echo $URI.'/'.$server->id; ?>" class="btn btn-primary"><i class="fa fa-shopping-cart fa-fw"></i>Buy</a>
                        <a href="http://<?php echo $server->host; ?>/client.ovpn" class="btn btn-default"><i class="fa fa-download fa-fw"></i>Config</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>