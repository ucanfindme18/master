<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                <?php if ($server->id): ?>
                    
                        <?php echo $server->servername; ?>
                    
                    <?php else: ?>
                        Add Server
                    
                <?php endif; ?>
            </h1>
        </div>
    </div>
    <div class="row">
        <?php if ($message): ?>
            <div class="col-lg-12">                    
                <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
            </div>
        <?php endif; ?>
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-gear fa-fw"></i> Server Settings
                </div>
                <div class="panel-body">
                    <form role="form" action="<?php echo $URI; ?>" method="POST">
                        <div class="form-group">
                            <label>Server Name</label>
                            <input class="form-control" placeholder="Server Demo 1" name="servername" type="text" value="<?php echo $server->servername; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Server Location</label>
                            <input class="form-control" placeholder="Singapore" name="country" type="text" value="<?php echo $server->country; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>IP / Host</label>
                            <input class="form-control" placeholder="" name="host" type="text" value="<?php echo $server->host; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Price / Month</label>
                            <div class="input-group">
                                <span class="input-group-addon">PHP </span>
                                <input class="form-control" placeholder="10000" name="price" type="number" step="100" value="<?php echo $server->price; ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Root Password</label>
                            <input class="form-control" placeholder="root_password" name="root_pass" type="password">
                        </div>
                        <button class="btn btn-primary">Save</button>
                        <?php if ($server->id): ?>
                            <?php if ($server->active==1): ?>
                                
                                    <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">Lock</a>
                                
                                <?php else: ?>
                                    <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">Unlock</a>
                                
                            <?php endif; ?>
                            <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger hapus">Delete</a>
                        <?php endif; ?>
                        <a href="/home/admin/server" class="btn btn-default">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>