<section id="#login">
    <div class="container">
        <div class="row ver-parent">
            <div class="col-md-4 col-md-offset-4 ver-center">
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
                <?php endif; ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                      <center>
                      <div class="loginpic"><img src="https://assets.pcmag.com/media/images/464330-openvpn-2-4-3-logo.jpg?width=333&height=245"></div>
                        <h3 class="panel-title"> </h3>
                      </center>
                    </div>
                    <div class="panel-body">
                        <form role="form" action="/login" method="POST">
                            <fieldset>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                                        <input class="form-control" placeholder="Username" name="username" type="text" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                                        <input class="form-control" placeholder="Password" name="password" type="password" required>
                                    </div>
                                </div>
                                <button class="btn btn-lg btn-success btn-block">Login</button>
                            </fieldset>
                        </form>
                      <h3 class="panel-title"><center><sub>All Rights Reserved 2019</sub></center></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
