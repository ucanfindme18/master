<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                <?php echo $server->servername; ?>
            </h1>
        </div>
    </div>
    <div class="row">
        <?php if ($message): ?>
            <div class="col-lg-12">                    
                <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
            </div>
        <?php endif; ?>
        <div class="col-md-4 col-lg-3">
            <div class="row">
                <div class="col-xs-6 col-md-12">
                    <div class="well">Balance : <B><?php echo $me->saldo; ?></B></div>                    
                </div>
                <div class="clearfix"></div>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b><?php echo $server->servername; ?></b> <?php echo $server->active==1?'':'( Locked )'; ?>
                        </div>
                        <table class="table">
                            <tr>
                                <td>Location</td><td><?php echo $server->country; ?></td>
                            </tr>
                            <tr>
                                <td>Host</td><td><?php echo $server->host; ?></td>
                            </tr>
                            <tr>
                                <td>Price</td><td><?php echo $server->price; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-shopping-cart fa-fw"></i> Server Settings
                </div>
                <div class="panel-body">
                    <form role="form" action="<?php echo $URI; ?>" method="POST">
                        <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" placeholder="Sudirman" name="user" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input class="form-control" placeholder="New Password" name="pass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter Password</label>
                            <input class="form-control" placeholder="Re-enter Password" name="pass_confirmation" type="password" required>
                        </div>
                        <button class="btn btn-primary">Save</button>
                        <a href="/home/member/server" class="btn btn-default">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>